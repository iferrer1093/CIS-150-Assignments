﻿using System;
using System.Diagnostics.Metrics;
using System.Linq.Expressions;
using System.Reflection.Metadata;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Hands_on_Exam_for_C_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int number;
            int counter = 1;
            int largest;



            do
            {
            Console.WriteLine("Please Enter a positive Number above 0!");
            number = Convert.ToInt32(Console.ReadLine());

                if (number <= 0)
                {
                    Console.WriteLine("You cannot use 0 or a negative number");
                }
                else
                {
                    Console.WriteLine("Counter: " + counter);
                    counter += 1;
                    Console.WriteLine(number);
                }





                /*
                try
                {
                    Console.WriteLine("Please Enter a positive Number above 0!");
                    number = Convert.ToInt32(Console.ReadLine());
                }
                catch (Exception );
                */



            } while (counter <= 10);










        }
    }
}
